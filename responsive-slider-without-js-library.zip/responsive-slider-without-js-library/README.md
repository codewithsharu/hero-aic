# Responsive Slider without JS Library

A Pen created on CodePen.

Original URL: [https://codepen.io/ecemgo/pen/WNappPz](https://codepen.io/ecemgo/pen/WNappPz).

Note: Please, do not use it in profit-making platforms and projects without permission.